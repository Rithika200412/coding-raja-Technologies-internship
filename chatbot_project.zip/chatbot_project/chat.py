
import random
import json
import numpy as np
import pickle
from tensorflow.keras.models import load_model
from nltk_utils import bag_of_words, tokenize

model = load_model('models/chatbot_model.h5')
words = pickle.load(open('models/words.pkl', 'rb'))
classes = pickle.load(open('models/classes.pkl', 'rb'))

with open('data/intents.json') as file:
    intents = json.load(file)

def predict_class(sentence):
    bag = bag_of_words(tokenize(sentence), words)
    res = model.predict(np.array([bag]))[0]
    ERROR_THRESHOLD = 0.25
    results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD]
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({'intent': classes[r[0]], 'probability': str(r[1])})
    return return_list

def get_response(intents_list, intents_json):
    tag = intents_list[0]['intent']
    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if i['tag'] == tag:
            return random.choice(i['responses'])

print("Start talking with the bot (type 'quit' to stop)!")
while True:
    message = input("")
    if message.lower() == "quit":
        break
    ints = predict_class(message)
    res = get_response(ints, intents)
    print(res)
